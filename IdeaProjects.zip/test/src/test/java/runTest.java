/**
 * Created by Administrator on 11/21/2018.
 */


import org.junit.runner.RunWith;
import cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options (
        format = {"pretty"},
        features = {"src/test/java/resources/test1.feature"}
)

public class runTest { }

