package test;

import org.apache.jasper.tagplugins.jstl.core.If;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.IFactoryAnnotation;

import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 11/15/2018.
 */
public class checkusername {
    public static void main(String[] args) throws InterruptedException {


            WebDriver driver = new ChromeDriver();

            System.setProperty("webdriver.chrome.driver", "C:\\WebDriver\\Chromedriver\\chromedriver.exe");
//
            driver.get("https://cclite.beta.qup.vn/login?redirect=/");
//
            driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);


            WebElement username = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input"));

            username.sendKeys("vile");

            WebElement password = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input"));

            password.sendKeys("abc123!@#");

            WebElement submit = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button/span"));

            submit.click();

            Thread.sleep(5000);
            WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]"));
            System.out.println(errorMessage.getText());
            Assert.assertEquals("The username or password you entered is incorrect. Please try again", errorMessage.getText());

            driver.close();
    }



}


//    public void set_username(String usern){
//
//
//    }
//    public void set_password(String pass){
//
//    }
//    public void click_bt(){
//
//    }
//    @Test
//    public void test1(){
//        NewCC t= new NewCC();
//        t.set_username("abc");
//        t.set_password("qưp");
//        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]"));
//        System.out.println(errorMessage.getText());
//        Assert.assertEquals("The username or password you entered is incorrect. Please try again", errorMessage.getText());
//    }






        //System.out.println("aaaaaaaa");



       // Assert.assertEquals("The username or password you entered is incorrect. Please try again", errorMessage.getText());


