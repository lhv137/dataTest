package test;

import jdk.internal.org.objectweb.asm.tree.TryCatchBlockNode;
import org.apache.jasper.tagplugins.jstl.core.Catch;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.xml.sax.SAXParseException;
import org.testng.TestNGException;

/**
 * Created by Administrator on 11/16/2018.
 */
public class checkLoginsuccessfull {
    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
       // System.setProperty("webdriver.chrome.driver", "C:\\WebDriver\\Chromedriver\\chromedriver.exe");

        String expectedTitle = "Dashboard";
        boolean value = true;
        //String actualTitle = driver.getTitle();

        driver.get("https://cclite.beta.qup.vn/login?redirect=/");

       // driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);


        WebElement username = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input"));

        username.sendKeys("vileh");

        WebElement password = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input"));

        password.sendKeys("abc123!@#");

        WebElement submit = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button/span"));

        submit.click();

        Thread.sleep(5000);
       // WebElement myDynamicElement = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("page-content")));
        if (driver.getTitle().equalsIgnoreCase(expectedTitle)){
            value=true;
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed!\n");
        }



        //System.out.print(driver.getTitle().equalsIgnoreCase(expectedTitle));
        //System.out.print(expectedTitle);


        //        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]"));
//        System.out.println(errorMessage.getText());
//        try {
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]")).isDisplayed();
//            Assert.assertEquals("The username or password you entered is incorrect. Please try again", errorMessage.getText());
//
//        }catch (Exception e){
//            System.out.print("Passed");
//        try {
//            driver.findElement(By.id("page-content")).isDisplayed();
//            System.out.print("Passed");
//        }catch (Exception e){
//            System.out.print("Failed");
//        }
       // if (driver.findElement(By.id("page-content")).isDisplayed()){
       //     System.out.print("Passed");
       // }

//            if (driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]")).isDisplayed()){
//            System.out.print("Failed");
//        }
//            if (driver.findElement(By.id("page-content")).isDisplayed()){
//            System.out.print("Passed");}else  {
//                System.out.print("Failed");
//            }
        driver.close();
}
}
