package test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
/**
 * Created by Administrator on 11/19/2018.
 */
public class testSettings {
    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        String expected1 ="Home of Vĩ1";
        String expected2 ="+84989212464";
        String expected3 ="lehoangvidt@gmail.com";
        String expected4 ="Vietnam2";
        String expected5 ="Asia/Ho_Chi_Minh";
        String expected6 ="2 Quang Trung Đà Nẵng";
        String expected7 ="https://cclite.beta.qup.vn3";
        String expected8 ="VND";
        String expected9 ="km4";

        driver.get("https://cclite.beta.qup.vn/settings/Fleet_info");
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys("vile");
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys("abc123!@#");
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();

        Thread.sleep(5000);
        WebElement fleet = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[1]/input"));


        WebElement phone = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[2]/input"));


        WebElement email = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[3]/input"));


        WebElement country = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[4]/input"));


        WebElement timezone = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[5]/input"));


        WebElement address = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[6]/input"));


        WebElement website = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[7]/input"));


        WebElement currency = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[8]/input"));


        WebElement distance = driver.findElement(By.xpath("//*[@id=\"page-content\"]/div/div/div[2]/div/div/div/div[9]/input"));


//        System.out.print(fleet.getAttribute("1"));
        if(fleet.getAttribute("value").equalsIgnoreCase(expected1)){
            System.out.print("Test 1 Passed\n");
//            System.out.print(fleet.getText());
        }else{
            System.out.print("Test 1 Failed\n");
        }
        if(phone.getAttribute("value").equalsIgnoreCase(expected2)){
            System.out.print("Test 2 Passed\n");
        }else{
            System.out.print("Test 2 Failed\n");
        }
        if(email.getAttribute("value").equalsIgnoreCase(expected3)){
            System.out.print("Test 3 Passed\n");
        }else{
            System.out.print("Test 3 Failed\n");
        }
        if(country.getAttribute("value").equalsIgnoreCase(expected4)){
            System.out.print("Test 4 Passed\n");
        }else{
            System.out.print("Test 4 Failed\n");
        }
        if(timezone.getAttribute("value").equalsIgnoreCase(expected5)){
            System.out.print("Test 5 Passed\n");
        }else{
            System.out.print("Test 5 Failed\n");
        }
        if(address.getAttribute("value").equalsIgnoreCase(expected6)){
            System.out.print("Test 6 Passed\n");
        }else{
            System.out.print("Test 6 Failed\n");
        }
        if(website.getAttribute("value").equalsIgnoreCase(expected7)){
            System.out.print("Test 7 Passed\n");
        }else{
            System.out.print("Test 7 Failed\n");
        }
        if(currency.getAttribute("value").equalsIgnoreCase(expected8)){
            System.out.print("Test 8 Passed\n");
        }else{
            System.out.print("Test 8 Failed\n");
        }
        if(distance.getAttribute("value").equalsIgnoreCase(expected9)){
            System.out.print("Test 9 Passed\n");
        }else{
            System.out.print("Test 9 Failed\n");
        }
        driver.close();
    }
}