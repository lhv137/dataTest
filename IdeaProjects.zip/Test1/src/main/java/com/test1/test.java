package com.test1;

/**
 * Created by Administrator on 11/19/2018.
 */
public class test {
        public String checkPlay(int playedNumber) {
            return Integer.toString(playedNumber);
        }

}
