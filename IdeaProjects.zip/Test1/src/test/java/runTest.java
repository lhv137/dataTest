/**
 * Created by Administrator on 11/20/2018.
 */
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/java/resources/testthu.feature"
        ,glue={"stepDefinition"}
)
//
//@CucumberOptions(features = "src/test/java/resources/dataTable.feature",
//        format = { "pretty",
//                "html:target/site/cucumber-pretty",
//                "rerun:target/rerun.txt",
//                "json:target/cucumber1.json" })


public class runTest {
}
