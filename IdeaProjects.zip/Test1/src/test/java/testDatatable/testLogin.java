package testDatatable;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 11/20/2018.
 */
public class testLogin {


    WebDriver driver = null;
    String expectedTitle = "Dashboard";
    String successfull = null;
    String failed = null;

//    @Given("^Login NewCC in \"([^\"]*)\"$")
//    public void Login_NewCC_in(String arg1) throws Throwable {
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        driver.get(arg1);
//    }
//
//    @When("^I input credentials with Username and Password$")
//    public void I_input_credentials_with_Username_and_Password(DataTable table) throws Throwable {
//        List<List<String>> data = table.raw();
////
////        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys(data.get(1).get(0));
////        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys(data.get(1).get(1));
////        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
////        Thread.sleep(5000);
//
//
////      System.out.println(data.get(0).get(0).toString());
////      System.out.println(data.get(0).get(1).toString());
//
//
//        for (int i = 1; i < data.size(); i++) {
//
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).clear();
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys(data.get(i).get(0));
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).clear();
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys(data.get(i).get(1));
//            driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
//            Thread.sleep(5000);
//            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
//
//            if (driver.getTitle().equalsIgnoreCase(expectedTitle)) {
//                System.out.print("Login Passed\n");
//
//            } else {
//                System.out.print("Login Failed\n");
//            }
//
//
//            driver.close();
//
//
//        }
//
//    }
//
//
//    @Then("^I get result Login \"([^\"]*)\"$")
//    public void I_get_result_Login(String arg1) throws Throwable {
//
//
////        String err = "The username or password you entered is incorrect. Please try again";
////
////        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]/span"));
////
////        if (arg1.equalsIgnoreCase("Successful")) {
////            if (driver.getTitle().equalsIgnoreCase(expectedTitle)) {
////                System.out.println("Login Success!");
////            } else {
////                System.out.print("Login Failed");
////            }
////            driver.close();
////        List<Result> resultList = arg1.asList(Result.class);
////        for (Result result: resultList){
////            System.out.println(result);
////        }
//    }
//}
    @Given("^Login NewCC in \"(.*?)\"$")
    public void login_NewCC_in(String arg1) throws Throwable {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(arg1);

    }


    @When("^I input credentials with \"([^\"]*)\" and \"([^\"]*)\" :$")
    public void I_input_credentials_with_and_(String username, String password) throws Throwable {
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).clear();
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys(username);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).clear();
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys(password);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
    }

    @Then("^I get \"([^\"]*)\" Login :$")
    public void I_get_Login_(String results) throws Throwable {
            if (driver.getTitle().equalsIgnoreCase(expectedTitle)) {
                System.out.println("Login Success!");
            } else {
                System.out.print("Login Failed");
            }
            driver.close();
        }


    }
//


//}
//
//    @When("^I click Login button$")
//    public void I_click_Login_button() throws Throwable {
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
//        Thread.sleep(5000);
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


//    }


//    public class Result {
//        private String username=null;
//        private String password = null;
//        private String result = null;
//
//        public Result(String user, String pass, String res) {
//            this.username = user;
//            this.password = pass;
//            this.result =res;
//
//        }
//    }




//

//    @Then("^I get result login$")
//    public void I_get_result_login() throws Throwable {
//        System.out.print("\nLogin\n");
//        String err = "The username or password you entered is incorrect. Please try again";
//
//        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]/span"));
//
//        if(result.equalsIgnoreCase("successful")){
//            if (driver.getTitle().equalsIgnoreCase(expectedTitle)){
//                System.out.println("Login Success!");
//            }else{
//                System.out.print(errorMessage.getText());
//            }
////            if (errorMessage.getText().equalsIgnoreCase(err)){
////                    System.out.println("Test Login Passed!");
////                } else {
////                System.out.println("Test Login Failed!\n");
////                }
//            driver.close();
//        }
//    }


//    }









//
//    @When("^I input credentials with Username and Password$")
//    public void I_input_credentials_with_username_and_password(DataTable arg1) throws Throwable {
//       //List<String> list = arg1.asList(String.class);
//        List<List<String>> data = arg1.raw();
//        System.out.println(data.get(0).get(0));
//        System.out.println(data.get(1).get(1));
//
//    }
//
//
//    @Then("^I get result with |username||passwword||result|$")
//    public void I_get_result_with_username_passwword_result() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//        throw new PendingException();
//    }



