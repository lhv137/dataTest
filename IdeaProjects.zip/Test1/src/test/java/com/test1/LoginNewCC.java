package com.test1;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 11/19/2018.
 */
public class LoginNewCC {
    WebDriver driver = null;
    String expectedTitle = "Dashboard";

//    @Given("^Go to \"([^\"]*)\"$")
//    public void Login_NewCC_in(String arg1) throws Throwable {
//        // Express the Regexp above with the code you wish you had
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//        driver.get(arg1);
//
//    }

//    @When("^User login username and password correct$")
//    public void User_login_username_and_password_correct() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys("vile");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys("abc123!@#");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
//        Thread.sleep(3000);
//
//      //  throw new PendingException();
//    }
//
//    @Then("^Login successful$")
//    public void Login_successful() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//
//        if (driver.getTitle().equalsIgnoreCase(expectedTitle)){
//            value=true;
//            System.out.println("Login Success!");
//        } else {
//            System.out.println("Login Failed!\n");
//        }
//        driver.close();
//        //throw new PendingException();
//    }
//
//
//    @When("^User login username correct and password incorrect$")
//    public void User_login_username_correct_and_password_incorrect() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys("vile");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys("abc123!@#1");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
//        Thread.sleep(5000);
//
//        //throw new PendingException();
//    }
//
//    @Then("^Login Error Password$")
//    public void Login_Error_Password() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]/span"));
//
//        String err ="The username or password you entered is incorrect. Please try again";
//        if (errorMessage.getText().equalsIgnoreCase(err)){
//            System.out.println("Test Passed!");
//            //System.out.print(errorMessage.getText());
//        } else {
//            System.out.println("Test Failed!\n");
//        }
//        driver.close();
////        System.out.println(errorMessage.getText());
////        Assert.assertEquals("The username or password you entered is incorrect. Please try again\n", errorMessage.getText());
//
//        //throw new PendingException();
//    }
//
//    @When("^User login username incorrect and password correct$")
//    public void User_login_username_incorrect_and_password_correct() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys("vile1");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys("abc123!@#");
//        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
//        Thread.sleep(5000);
//        //throw new PendingException();
//    }
//
//    @Then("^Login Error Username$")
//    public void Login_Error_Username() throws Throwable {
//        // Express the Regexp above with the code you wish you had
//        String err = "The username or password you entered is incorrect. Please try again";
//
//        WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]/span"));
//        if (errorMessage.getText().equalsIgnoreCase(err)){
//            System.out.println("Test Login Passed!");
//        } else {
//            System.out.println("Test Login Failed!\n");
//        }
//        driver.close();
//
//
//    }

    @When("^User login username is \"([^\"]*)\" and password is \"([^\"]*)\"$")
    public void User_login_username_is_and_password_is(String username, String pass) throws Throwable {


        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[2]/input")).sendKeys(username);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[3]/input")).sendKeys(pass);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/button")).click();
        Thread.sleep(3000);
    }

    @Then("^I get result is \"([^\"]*)\"$")
    public void I_get_result_is(String result) throws Throwable {

        String err = "The username or password you entered is incorrect. Please try again";

       // WebElement errorMessage = driver.findElement();
       WebElement errorMessage = driver.findElement(By.xpath("//*[@id=\"root\"]/div/form/div/div[1]/span"));


        if(result.equalsIgnoreCase("successful")){
            if (driver.getTitle().equalsIgnoreCase(expectedTitle)){
                System.out.println("Login Success!");
            }else{
                System.out.print(errorMessage.getText());
            }
//            if (errorMessage.getText().equalsIgnoreCase(err)){
//                    System.out.println("Test Login Passed!");
//                } else {
//                System.out.println("Test Login Failed!\n");
//                }
            driver.close();
    }
    }


}
